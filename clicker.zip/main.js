let clicks = 0;
const p = document.getElementById('p');
document.getElementById('click').addEventListener('click', click);
function click() {
  clicks += 1;
  window.location.hash = `#${clicks}`;
  update();
}
function update(){
  p.textContent = window.location.hash.split('#')[1];
}